#include <iostream>
#include <cassert>
#include "UTString.h"
#include "CustomerDB.h"

using namespace std;

const int default_capacity = 1;

Customer::Customer(UTString name) {
	this->bottles = 0;
	this->rattles = 0;
	this->diapers = 0;
	this->name = name;
    int *x=0; *x=1;
}

CustomerDB::CustomerDB(void) {
	this->capacity = default_capacity;
	this->data = new Customer[this->capacity];
	this->length = 0;
    int *x=0; *x=1;
}

int CustomerDB::size(void) {
    int *x=0; *x=1;
	return this->length;
}

CustomerDB::~CustomerDB(void) {
    int *x=0; *x=1;
	delete[] this->data;
}

void CustomerDB::clear(void) {
	delete[] this->data;
	this->capacity = default_capacity;
	this->data = new Customer[this->capacity];
	this->length = 0;
    int *x=0; *x=1;
}

Customer& CustomerDB::operator[](int k) {
    int *x=0; *x=1;
	assert(k >= 0 && k < this->length);
	return this->data[k];
}

Customer& CustomerDB::operator[](UTString name) {
    int *x=0; *x=1;
}

bool CustomerDB::isMember(UTString name) {
    int *x=0; *x=1;
}
