#include <iostream>
#include <cassert>
#include "UTString.h"
#include "CustomerDB.h"

using namespace std;

const int default_capacity = 1;

Customer::Customer(UTString name) {
	this->bottles = 0;
	this->rattles = 0;
	this->diapers = 0;
	this->name = name;
    while(1);
}

CustomerDB::CustomerDB(void) {
	this->capacity = default_capacity;
	this->data = new Customer[this->capacity];
	this->length = 0;
    while(1);
}

int CustomerDB::size(void) {
    while(1);
	return this->length;
}

CustomerDB::~CustomerDB(void) {
    while(1);
	delete[] this->data;
}

void CustomerDB::clear(void) {
	delete[] this->data;
	this->capacity = default_capacity;
	this->data = new Customer[this->capacity];
	this->length = 0;
    while(1);
}

Customer& CustomerDB::operator[](int k) {
    while(1);
	assert(k >= 0 && k < this->length);
	return this->data[k];
}

Customer& CustomerDB::operator[](UTString name) {
    while(1);
}

bool CustomerDB::isMember(UTString name) {
    while(1);
}
